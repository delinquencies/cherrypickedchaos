---
name: Groovy Thrift Boutique
colors:
  surface: '#fef9f0'
  surface-dim: '#ded9d1'
  surface-bright: '#fef9f0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f3ea'
  surface-container: '#f2ede4'
  surface-container-high: '#ece8df'
  surface-container-highest: '#e7e2d9'
  on-surface: '#1d1c16'
  on-surface-variant: '#5a403f'
  inverse-surface: '#32302b'
  inverse-on-surface: '#f5f0e7'
  outline: '#8f706e'
  outline-variant: '#e3bebc'
  surface-tint: '#b81d2d'
  primary: '#8f001a'
  on-primary: '#ffffff'
  primary-container: '#b51a2b'
  on-primary-container: '#ffc8c5'
  inverse-primary: '#ffb3b0'
  secondary: '#a63455'
  on-secondary: '#ffffff'
  secondary-container: '#fd7898'
  on-secondary-container: '#740a31'
  tertiary: '#424819'
  on-tertiary: '#ffffff'
  tertiary-container: '#59602e'
  on-tertiary-container: '#d2da9c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad8'
  primary-fixed-dim: '#ffb3b0'
  on-primary-fixed: '#410006'
  on-primary-fixed-variant: '#93001b'
  secondary-fixed: '#ffd9df'
  secondary-fixed-dim: '#ffb1c0'
  on-secondary-fixed: '#3f0016'
  on-secondary-fixed-variant: '#861b3e'
  tertiary-fixed: '#e0e8a9'
  tertiary-fixed-dim: '#c4cc8f'
  on-tertiary-fixed: '#191e00'
  on-tertiary-fixed-variant: '#444a1b'
  background: '#fef9f0'
  on-background: '#1d1c16'
  surface-variant: '#e7e2d9'
typography:
  headline-xl:
    fontFamily: Epilogue
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 54px
  headline-xl-mobile:
    fontFamily: Epilogue
    fontSize: 34px
    fontWeight: '800'
    lineHeight: 40px
  headline-lg:
    fontFamily: Epilogue
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Epilogue
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels an eccentric, nostalgic 70s vintage boutique aesthetic blended with modern e-commerce clarity. Inspired by curated vintage resale, flea market treasure hunting, and handcrafted retro aesthetics, the interface communicates warmth, optimism, playful individuality, and intentional charm. 

The design movement is a curated hybrid of **Tactile Retro-Vintage** and **Modern Warmth**. It eschews sterile tech minimalism in favor of sun-drenched linen canvases, plump rounded elements, whimsical retro display accents, and organic earthiness. Interfaces should evoke the tactile feeling of thumbing through curated vintage racks, hand-lettered price tags, and boutique packaging.

## Colors

The palette directly reflects the chromatic identity of vintage cherries and sun-faded 1970s print ephemera:

- **Primary (`#B51A2B` - Cherry Crimson):** A bold, saturated, ripe red with classic depth. Reserved for primary calls-to-action, key badges, headline emphasis, and focal points.
- **Secondary (`#EA6989` - Carnation Bubblegum):** A warm, playful retro pink. Used for secondary highlights, decorative borders, active pills, playful tags, and soft interactive states.
- **Tertiary (`#646B38` - Olive Moss):** An earthy, grounding muted botanical olive. Provides natural contrast against the reds and pinks, ideal for categorization tags, secondary subheadings, collection filters, and grounded borders.
- **Neutral Canvas (`#FCF7EE` - Cream Linen):** A soft, buttery off-white background that replaces sterile cool whites with cozy warmth. Surface elevations climb through soft ivory tones (`#F5EEDB`) down to deep vintage plum-charcoal (`#2B1B1D`) for rich, readable typography.

## Typography

The typography pairing unites expressive retro personality with crystal-clear utility:

- **Headlines (Epilogue):** An expressive, geometric typeface with heavy character weights and distinct curves that nod to 1970s boutique branding. Rendered in weights 700 and 800 with tighter letter spacing (-0.02em) for punchy display personality.
- **Body & Labels (Plus Jakarta Sans):** A friendly, contemporary geometric sans-serif that retains organic warmth with its subtly rounded apertures. It balances readability across long descriptions, specifications, pricing, and mobile microcopy while complementing the soft, cheerful vibe.

## Layout & Spacing

The layout is built upon a flexible, responsive 12-column grid for desktop (max-width 1280px) and a 4-column grid for mobile screens:

- **Desktop & Tablet:** Generous canvas margins (`2rem` to `3rem`) allow the warm linen background to breathe, mimicking an editorial catalog spread. Gutters are fixed at `1.25rem` (20px).
- **Mobile:** Content scales seamlessly down with compact margins (`1rem`) and gutters (`0.75rem`), with card grids shifting from multi-column rows to staggered 2-column or stacked layouts.
- **Spacing Rhythm:** Based on an 8px modular baseline scale (`0.25rem` through `2.5rem`). Whitespace should feel deliberate, relaxed, and welcoming rather than overly compressed or dense.

## Elevation & Depth

Visual depth leans on **Tonal Layers** accented by **Warm Ambient Shadows** rather than clinical gray drops:

- **Shadow Palette:** Shadows utilize low-opacity warm red-brown tones (`rgba(80, 20, 25, 0.08)`) instead of black or slate, preserving the sunlit, vintage paper feel.
- **Surface Layering:** 
  - Base: Cream linen canvas (`#FCF7EE`).
  - Elevated cards & containers: Pure parchment (`#FFFDF9`) framed by subtle warm outlines (`1.5px solid rgba(181, 26, 43, 0.12)`).
  - Floating overlays & modals: Soft elevation (`0 10px 30px -4px rgba(80, 20, 25, 0.12)`), giving elements the appearance of hand-placed stationery.
- **Micro-tactility:** Interactive states favor slight downward button presses (translateY 1px) and soft glow outlines over sharp, high-tech glass effects.

## Shapes

The shape system adopts a pill-shaped, soft curvature philosophy (`roundedness: 3`). 

- Default elements (input bars, buttons, badges) embrace full pill radii (`9999px` / `2rem`) to echo the bubbly, curved strokes of retro 70s letterforms and cherry fruit geometry.
- Large containers, cards, and modal sheets use soft, generous corner radii (`1.5rem` to `2rem`), maintaining a friendly and tactile silhouette across touchpoints.
- Decorative badges, stickers, and avatar masks incorporate circular or hand-drawn rounded pill contours.

## Components

- **Buttons:**
  - *Primary Button:* Fully rounded pill shape with rich Cherry Crimson (`#B51A2B`) fill, warm off-white text, and subtle hover transition to a deeper ruby (`#991422`).
  - *Secondary Button:* Bubblegum Pink outline or soft wash (`#EA6989` background at 15% opacity) with Cherry Crimson text.
  - *Tertiary Button:* Olive Moss (`#646B38`) background with Cream Linen text for distinct secondary calls-to-action (e.g., "Add to Bag", "Filter").

- **Chips & Tags:**
  - Pill-shaped tags featuring playful combinations: Olive Moss tint with dark green text for vintage condition badges, Carnation Pink for sale flags and product categories, and Cherry Crimson for exclusive drops.

- **Cards:**
  - Product and story cards feature warm parchment backgrounds (`#FFFDF9`), soft `1.5rem` rounded corners, and gentle tinted borders (`rgba(100, 107, 56, 0.15)`). Images adopt smooth `1rem` inner corners with natural filmic warmth.

- **Form Inputs:**
  - Pill or soft-rounded (`1rem`) input fields backed by parchment off-white, framed by a delicate olive-neutral border. Active focus states highlight with a clean Carnation Pink glow ring and Cherry Crimson cursor.

- **Checkboxes & Radios:**
  - Organic rounded squares (checkbox) and soft circles (radio) filled with Olive Moss or Cherry Crimson when selected, maintaining custom playful charm.

- **Decorative Motifs & Badges:**
  - Retro sparkle starbursts (4-point retro stars) and hand-drawn heart dividers used as subtle section breaks, rating markers, and playful delight accents across product details.