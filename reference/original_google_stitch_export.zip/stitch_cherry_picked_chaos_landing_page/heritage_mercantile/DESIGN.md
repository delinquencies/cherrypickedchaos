---
name: Heritage Mercantile
colors:
  surface: '#fff8f5'
  surface-dim: '#e1d8d3'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf2ed'
  surface-container: '#f5ece7'
  surface-container-high: '#efe6e1'
  surface-container-highest: '#eae1dc'
  on-surface: '#1f1b18'
  on-surface-variant: '#55433e'
  inverse-surface: '#34302c'
  inverse-on-surface: '#f8efea'
  outline: '#88726c'
  outline-variant: '#dbc1ba'
  surface-tint: '#99452d'
  primary: '#96432b'
  on-primary: '#ffffff'
  primary-container: '#b55b41'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb5a0'
  secondary: '#516350'
  on-secondary: '#ffffff'
  secondary-container: '#d3e8d0'
  on-secondary-container: '#576956'
  tertiary: '#7b5802'
  on-tertiary: '#ffffff'
  tertiary-container: '#96711f'
  on-tertiary-container: '#090400'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd1'
  primary-fixed-dim: '#ffb5a0'
  on-primary-fixed: '#3b0900'
  on-primary-fixed-variant: '#7a2f18'
  secondary-fixed: '#d3e8d0'
  secondary-fixed-dim: '#b8ccb5'
  on-secondary-fixed: '#0f1f10'
  on-secondary-fixed-variant: '#394b3a'
  tertiary-fixed: '#ffdea4'
  tertiary-fixed-dim: '#eec067'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#fff8f5'
  on-background: '#1f1b18'
  surface-variant: '#eae1dc'
typography:
  display:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-xxl: 4rem
---

## Brand & Style

This design system channels the warmth, heritage, and treasure-hunting romance of a curated Central Texas mercantile hall. It evokes the feeling of walking across creaking pine floors, flipping through weathered tags on mid-century sideboards, and unearthing hand-pressed glass. The emotional response is grounded, trustworthy, tactile, and thoughtfully eclectic—never dusty or cluttered, but meticulously edited.

The aesthetic fuses **Tactile Editorial** with **Historic Mercantile**:
- Physical metaphors drawn from vintage ephemera: dry-embossed framing lines, scalloped or notched card motifs, and ink-stamped editorial labels.
- Warm, breathable negative space mimicking sunlit linen backgrounds rather than sterile gallery whites.
- Balanced proportioning: stately, artisanal serifs command titles and historical storytelling, while crisp, modern sans-serifs bring utility and effortless readability to inventory catalogs, vendor listings, and event dates.

## Colors

The palette is rooted in historic Texas brick facades, dry sagebrush hillsides, and brass drawer pulls. 

- **Primary (`#B85D43` faded terracotta, deep shade `#A24B33`):** Evokes faded sun-baked brick and ironstone pottery. Applied to key calls-to-action, active dates, and prominent mercantile accents.
- **Secondary (`#687B67` sage green, deep shade `#4E614D`):** Reflects native Texas cedar and weathered garden iron. Applied to status tags (e.g., "Verified Vendor", "In Stock"), secondary controls, and leafy graphic accents.
- **Tertiary (`#C49A45` antique brass):** Used sparingly for specialty highlights, ribbon badges, and delicate metallic accents that suggest aged hardware.
- **Neutral (`#282421` deep espresso, dark shade `#1C1917`):** Replaces synthetic pure black with the natural density of vintage printers' ink.
- **Surfaces & Canvases:**
  - Base canvas: `#FAF7F2` (Warm Linen).
  - Raised surfaces & containers: `#F3EEE7` (Pressed Parchment).
  - Subtle architectural borders: `#D9CEBE` (Weathered Stone).

## Typography

Typography establishes an intentional dialogue between classic typesetting and modern clarity:

- **Headlines (Playfair Display):** Conveys the presence of hand-painted storefront windows and printed market gazettes. High stroke contrast with graceful transitional serifs adds gravitas to section headers and vendor titles.
- **Body & Labels (Plus Jakarta Sans):** Selected for its humanist warmth and open counters, ensuring high legibility for product descriptions, lot measurements, pricing, and directions.
- **Letter Spacing & Casing:** Small labels and tags utilize uppercase styling with wide tracking (`letterSpacing: 0.06em` to `0.08em`) to mirror archival specimen tags and historical ledger entries.

## Layout & Spacing

The layout is built upon an adaptive fluid grid structured around tactile pacing:

- **Mobile (&lt; 768px):** 4-column layout with `0.75rem` gutters and `1rem` safe page margins. Single-column card stacks ensure effortless tapability and high-resolution item inspections.
- **Tablet (768px – 1024px):** 8-column layout with `1.25rem` gutters and `2rem` outer canvas margins. Adapts smoothly to 2-column marketplace grids.
- **Desktop (&gt; 1024px):** 12-column grid capped at a maximum width of `1320px`, with `2rem` gutters and `3.5rem` outer margins. Content groups prioritize asymmetrical balance, pairing narrative vintage photos alongside structured catalog grids.

## Elevation & Depth

Visual hierarchy uses physical paper layering and delicate, low-contrast linework rather than synthetic, dark drop-shadows:

- **Tonal Layers:** Elevation shifts primarily through background tone, stepping from `#FAF7F2` (ground canvas) to `#F3EEE7` (cards and modules) to pure white `#FFFFFF` (popovers and active imagery).
- **Physical Borders:** Surfaces are delineated by crisp 1px borders in `#D9CEBE` (Weathered Stone). Key feature items and callout frames may feature an optional double-border ("railroad line") effect (1px solid border, 3px padding, 1px nested inner border) to mimic classic letterpress certificates.
- **Sunlit Ambient Shadows:** When floating interactive elements (modals, dropdown menus, dragging lot pins) require elevation, use an ultra-diffused, warm-tinted shadow: `0 8px 24px -4px rgba(40, 36, 33, 0.08), 0 2px 6px -1px rgba(40, 36, 33, 0.04)`.

## Shapes

The system adopts a crisp, soft-tailored structural contour (`roundedness: 1`):

- **Corners:** Buttons, containers, cards, and input fields use a tight `0.25rem` radius (`rounded-sm`). This replicates hand-trimmed cardstock and metal price plates rather than soft modern blobs.
- **Containers (`rounded-lg`):** Section overlays, modal sheets, and dialogue surfaces utilize `0.5rem` to retain architectural structure.
- **Arch Motifs:** Editorial feature banners and hero image containers may feature arched tops (`border-top-left-radius: 9999px; border-top-right-radius: 9999px`) honoring historic Schulenburg downtown storefronts and arched mercantile doorways.

## Components

### Buttons
- **Primary:** Solid terracotta (`#B85D43`) fill with cream (`#FAF7F2`) text. 1px tonal border (`#A24B33`). Hover shifts to deep terracotta (`#A24B33`) with subtle 1px translate lift.
- **Secondary / Mercantile Outline:** Transparent background, deep espresso (`#282421`) text, framed in a 1px solid `#D9CEBE` border. Hover turns background to `#F3EEE7`.
- **Tertiary / Antique Brass:** Used for VIP passes and specialty actions: Antique Brass (`#C49A45`) fill with deep espresso (`#282421`) text.
- **Metrics:** Min-height 44px (touch target friendly), padding `space-sm space-lg`, `label-lg` uppercase typography with `0.05em` letter spacing.

### Badges & Chips
- **Archival Tag Chips:** Reminiscent of manila string tags. Background `#F3EEE7`, text `#282421`, bordered in `#D9CEBE`.
- **Stamp Badges:** Status indicators ("Founders Lot", "Reserved", "Authentic Vintage") use a perforated or dashed 1px border (`#687B67` for active, `#B85D43` for sold/featured) with uppercase `label-sm` font.

### Cards
- **Marketplace Item Card:** Built on `#F3EEE7` with a 1px border (`#D9CEBE`). Images sit with an inner inset of `space-sm` to resemble framed photographs. Hover state deepens the border to `#B85D43` without dramatic dimensional pop.
- **Vendor Stall Card:** Incorporates an optional delicate header band in muted sage (`#687B67`) and an archival stamp badge for stall location (e.g., "BOOTH NO. 14").

### Form Inputs & Controls
- **Inputs:** Crisp linen background (`#FAF7F2`), 1px `#D9CEBE` border, deep espresso text. Focused state shifts border to terracotta (`#B85D43`) with a soft 2px `#B85D431A` ambient focus ring.
- **Checkboxes & Radios:** Sharp, tactile squircle-edges (`0.125rem` radius for checkboxes; full round for radios). Checked state fills with terracotta (`#B85D43`) with a crisp cream checkmark icon.

### Lists & Dividers
- **Dividers:** Fine 1px `#D9CEBE` rules. Sectional breaks may feature an ornamental center dot, brass starburst, or diamond glyph.
- **Ledger Lists:** Two-column vendor or price lists feature vintage dotted leaders connecting item names directly to price points.